class CTAIWidget {
    static init(config = {}) {
        const settings = {
            apiBase: config.apiBase || "http://10.10.251.160:8000",
            userId: config.userId,
            userKey: config.userKey,
            containerId: config.containerId || "ctai-widget-root",
            chatIconUrl: config.chatIconUrl || "chat.png"
        };
        if (!settings.userId || !settings.userKey) {
            const errorDiv = document.createElement("div");
            errorDiv.style.color = "red";
            errorDiv.textContent = "Error al inicializar el chat: Falta UserID o UserKey.";
            document.body.insertBefore(errorDiv, document.body.firstChild);
            return;
        }
        let container = document.getElementById(settings.containerId);
        if (!container) {
            container = document.createElement("div");
            container.id = settings.containerId;
            document.body.appendChild(container);
        } else {}
        container.innerHTML = `
            <div class="chat-bubble" onclick="window.CTAIChat.toggle()" aria-label="Abrir/Cerrar chat">
                <img src="${settings.chatIconUrl}" alt="Abrir chat" class="chat-icon">
            </div>
            <div class="chat-container" id="ctai-chat-container" style="display:none">
                <div class="chat-header">
                    <span>CT Ayuda</span>
                    <div class="buttons-container">
                        <button class="deleteButton" id="ctai-delete-history-button" aria-label="Eliminar historial">
                             <svg class="bin" viewBox="0 0 448 512">
                                 <path d="M135.2 17.7L128 32H32C14.3 32 0 46.3 0 64S14.3 96 32 96H416c17.7 0 32-14.3 32-32s-14.3-32-32-32H320l-7.2-14.3C307.4 6.8 296.3 0 284.2 0H163.8c-12.1 0-23.2 6.8-28.6 17.7zM416 128H32L53.2 467.6c1.6 16.7 15.6 28.4 32.3 28.4H362.5c16.7 0 30.7-11.7 32.3-28.4L416 128z"></path>
                             </svg>
                             <span class="tooltip">Eliminar</span>
                        </button>
                        <button class="close-button" onclick="window.CTAIChat.toggle()" aria-label="Cerrar chat">×</button>
                    </div>
                </div>
                <div class="chat-box" id="ctai-chat-box">
                    <div class="messages-container" id="ctai-messages-container">
                        <div class="chat-messages" id="ctai-chat-messages"></div>
                    </div>
                    <div class="chat-input" id="ctai-chat-input">
                        <textarea class="message-input" id="ctai-user-input" placeholder="Escribe tu mensaje" rows="1"></textarea>
                        <button class="send-button" id="ctai-send-button" aria-label="Enviar mensaje"></button>
                    </div>
                </div>
            </div>
        `;
        if (typeof marked === "undefined") {
            const scriptMarked = document.createElement("script");
            scriptMarked.src = "https://cdn.jsdelivr.net/npm/marked/marked.min.js";
            scriptMarked.onerror = () => {};
            document.head.appendChild(scriptMarked);
        }
        if (!document.querySelector('link[href="styles.css"]')) {
             const styleLink = document.createElement("link");
             styleLink.rel = "stylesheet";
             // *** CAMBIA ESTA LÍNEA SEGÚN TU AMBIENTE ***
             styleLink.href = "styles.css"; // Para probar en local
             // styleLink.href = "https://ctdev.ctonline.mx/static2/plugins/chatbot/styles.css"; // Para desplegar
             // styleLink.href = "https://pagina-dev.empresa.com/chatbot-api/styles.css"; // Proxy en dev
             document.head.appendChild(styleLink);
        } else {}
        window.CTAI_CONFIG = settings;
        window.CTAIChat = {
            toggle: () => {
                const chat = document.getElementById("ctai-chat-container");
                if(chat) {
                    const isHidden = !chat.style.display || chat.style.display === "none";
                    chat.style.display = isHidden ? "flex" : "none";
                    if (isHidden && typeof window.loadHistory === 'function') {
                         setTimeout(() => window.loadHistory(), 100);
                    } else if (isHidden && typeof window.loadHistory !== 'function'){
                         console.warn("CTAI App: loadHistory no está disponible después del toggle.");
                    }
                } else {}
            },
            sendMessageTrigger: () => {
                const sendButton = document.getElementById("ctai-send-button");
                if (sendButton) {
                    sendButton.click();
                } else {}
            }
        };
        if (!window.__CTAI_APP_LOADED__) {
            const scriptApp = document.createElement("script");
            scriptApp.src = "app.js"; // Para probar en local
            // scriptApp.src = "https://ctdev.ctonline.mx/static2/plugins/chatbot/app.js"; // Para desplegar
            scriptApp.defer = true;
            scriptApp.onload = () => {
                window.__CTAI_APP_LOADED__ = true;
                if (typeof window.initCTAIChatApp === 'function') {
                    window.initCTAIChatApp();
                } else {
                     const chatMessages = document.getElementById("ctai-chat-messages");
                     if (chatMessages) {
                         chatMessages.innerHTML = "<div class='bot-message'>Error crítico: No se pudo cargar la lógica del chat.</div>";
                     }
                }
            };
            scriptApp.onerror = () => {
                window.__CTAI_APP_LOADED__ = false;
                const chatMessages = document.getElementById("ctai-chat-messages");
                 if (chatMessages) {
                     if (typeof window.appendMessage === 'function') {
                         window.appendMessage("bot", "Error crítico: No se pudo cargar la lógica del chat.");
                     } else {
                          chatMessages.innerHTML = "<div class='bot-message'>Error crítico: No se pudo cargar la lógica del chat.</div>";
                     }
                 }
            }
            document.body.appendChild(scriptApp);
        } else {
             if (typeof window.initCTAIChatApp === 'function') {
                  window.initCTAIChatApp();
             } else {
                  console.warn("CTAIChat: app.js ya cargado pero window.initCTAIChatApp no encontrada en re-llamada.");
             }
        }
    }
}
const currentSdkScript = document.currentScript;
let autoInitConfig = null;
if (currentSdkScript && currentSdkScript.dataset.autoInit !== "false") {
    autoInitConfig = {
        userId: currentSdkScript.dataset.userId,
        userKey: currentSdkScript.dataset.userKey,
        apiBase: currentSdkScript.dataset.apiBase,
        chatIconUrl: currentSdkScript.dataset.chatIconUrl,
        containerId: currentSdkScript.dataset.containerId
    };
    if (!autoInitConfig.userId || !autoInitConfig.userKey) {
       console.error("CTAIChat: (Pre-init) Faltan data-user-id o data-user-key en el tag <script>. La auto-inicialización será omitida.");
       autoInitConfig = null;
    } else {}
} else if (!currentSdkScript) {
    console.warn("CTAIChat: document.currentScript es null. La auto-inicialización podría fallar si depende de data-*.");
} else {}
document.addEventListener("DOMContentLoaded", () => {
    if (autoInitConfig) {
        CTAIWidget.init(autoInitConfig);
    } else if (currentSdkScript?.dataset.autoInit !== "false") {
        console.warn("CTAIChat: No se pudo auto-inicializar debido a configuración faltante o incorrecta. Inicialice manualmente con CTAIWidget.init({...}).");
    } else {}
});